#!/bin/bash

cd $(pwd)
export LD_LIBRARY_PATH="$(pwd)/linux64:$(pwd):$LD_LIBRARY_PATH"

if [ ! -x "`which java`" ]; then echo "You have to install java first!"; exit 1; fi

MEMORY=$(grep -i 'server_memory' server.properties | tr -d '\n\r' | cut -f2 -d'=')
if [ -z "$MEMORY" ]; then
	echo "${txtred}No server_memory set. Server starts with 1024mb memory${txtreset}"
	MEMORY=1024
fi
if ! [[ $MEMORY =~ ^[0-9]+$ ]]; then
	echo "${txtred}The property 'server_memory' is not numeric${txtreset}"
	exit 1;
fi

java -Xmx${MEMORY}m -Xms$(($MEMORY/2))m -jar server.jar
